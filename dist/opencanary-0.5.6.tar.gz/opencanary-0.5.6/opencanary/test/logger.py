from opencanary.logger import logger

for i in range(10):
    logger.log({"Test": i, "Random" : "FJEd8dfdhsxf2f"})
