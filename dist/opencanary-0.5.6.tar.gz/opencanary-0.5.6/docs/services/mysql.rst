MySQL Server
================

Inside ~/.opencanary.conf:

.. code-block:: json

   {
        "mysql.banner": "5.5.43-0ubuntu0.14.04.1",
	"mysql.enabled": true,
	"mysql.port": 3306,
	"ssh.enabled": true,
	"ssh.port": 22,
	"ssh.version": "SSH-2.0-OpenSSH_5.1p1 Debian-4",
	[..] # logging configuration
   }

